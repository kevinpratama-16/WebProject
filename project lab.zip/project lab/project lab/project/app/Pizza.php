<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Cart;  
use App\Detail;  

class Pizza extends Model
{  
    protected $fillable = [];

    public function cart(){ 
        return $this->belongsToMany(Cart::class);
    } 

    public function detail(){ 
        return $this->belongsToMany(Detail::class);
    } 
}
