<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth; 
use Illuminate\Http\Request;
use App\Users;

class userController extends Controller
{
    public function viewAllUser(){  
        $users = Users::get();   

        return view('viewAllUser', compact('users'));
    }
}
