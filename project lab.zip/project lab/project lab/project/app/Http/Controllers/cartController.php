<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Cart;

class cartController extends Controller
{
    public function addToCart(Request $req){
        $this->Validate($req, [
            'pizzaQuantity'=>'required|numeric|min:1',
        ]);

        $currentUserId = Auth::user()->id;

        $itemOnCart=DB::select("select * from carts where user_id='$currentUserId' and pizza_id='$req->pizzaId'");

        if(!empty($itemOnCart[0])){
            $quantity = $req->pizzaQuantity + $itemOnCart[0]->quantity;
            DB::update("update carts set quantity = '$quantity' where user_id='$currentUserId' and pizza_id='$req->pizzaId'");
            return back()->withErrors('Success update cart');
        }
        else{
            $tempPizza= new Cart;
            $tempPizza->user_id = $currentUserId;
            $tempPizza->pizza_id = $req->pizzaId;
            $tempPizza->quantity = $req->pizzaQuantity;
            $tempPizza->save();
            return back()->withErrors('Success add to cart');
        }
    }

    public function viewCart(){
        $currentUser = Auth::user();
        $currentUserId = $currentUser->id;

        $listCarts = Cart::where('user_id','=', $currentUser->id)->get();
        return view('viewCart', compact('listCarts','currentUserId'));
    }

    public function updateQuantity(Request $req){
        $this->Validate($req, [
            'pizzaQuantity'=>'required|numeric|min:1',
        ]);

        $currentUserId = Auth::user()->id;

        $pizzaName =Cart::where('pizza_id','=',$req->pizzaId)->where('user_id','=',$currentUserId)->first()->pizza->first()->name;
        DB::update("update carts set quantity = '$req->pizzaQuantity' where user_id='$currentUserId' and pizza_id='$req->pizzaId'");

        return back()->withErrors("Success update quantity $pizzaName");;
    }

    public function removeCart(Request $req){
        $currentUserId = Auth::user()->id;
        $pizzaName =Cart::where('pizza_id','=',$req->pizzaId)->where('user_id','=',$currentUserId)->first()->pizza->first()->name;
        Cart::where('pizza_id','=',$req->pizzaId)->where('user_id','=',$currentUserId)->delete();

        return back()->withErrors("Success remove $pizzaName");
    }

}
