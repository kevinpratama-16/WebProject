<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Users;
use App\Pizza;
use App\Cart;
use App\Detail;

class pizzaController extends Controller
{
    public function homePage(){
        $listPizzas = Pizza::Paginate(6);

        $searchKey = "";
        return view('home', compact('listPizzas', 'searchKey'));
    }

    public function searchPizza(Request $req){
        if(!$req->pizzaName)
            return redirect('home');

        $searchKey = $req->pizzaName;

        $listPizzas = Pizza::where('name','like', '%'.$searchKey.'%')->Paginate(6);
        $listPizzas->appends($req->only('pizzaName'));

        return view('home', compact('listPizzas', 'searchKey'));
    }

    public function pizzaDetail(Request $req){
        $pizza = Pizza::where('id','=',$req->id)->get()->first();
        if($pizza == null)
            abort(404);
        return view('pizzaDetail', compact('pizza'));
    }

    public function addNewPizzaPage(){
        return view('addNewPizza');
    }

    public function doAddNewPizza(Request $req){
        $this->Validate($req, [
            'pizzaName'=>'required|max:20',
            'pizzaPrice'=>'required|numeric|min:10000',
            'pizzaDescription'=>'required|min:20',
            'pizzaImage'=>'mimes:jpeg,bmp,png',
        ]);

        $tempPizza= new Pizza;
        $tempPizza->name = $req->pizzaName;
        $tempPizza->price = $req->pizzaPrice;
        $tempPizza->description = $req->pizzaDescription;
        $tempPizza->image = $req->file('pizzaImage')->store('img','public');
        $tempPizza->save();

        return redirect('home');
    }

    public function updatePizzaPage(Request $req){
        $pizza = Pizza::where('id','=',$req->id)->get()->first();
        return view('updatePizza', compact('pizza'));
    }

    public function doUpdatePizza(Request $req){
        $this->Validate($req, [
            'pizzaName'=>'required|max:20',
            'pizzaPrice'=>'required|numeric|min:10000',
            'pizzaDescription'=>'required|min:20',
            'pizzaImage'=>'mimes:jpeg,bmp,png',
        ]);

        $tempPizza= Pizza::where('id','=',$req->id)->get()->first();;
        $tempPizza->name = $req->pizzaName;
        $tempPizza->price = $req->pizzaPrice;
        $tempPizza->description = $req->pizzaDescription;
        $tempPizza->image = $req->file('pizzaImage')->store('img','public');
        $tempPizza->save();

        return redirect('home');
    }

    public function deletePizzaPage(Request $req){
        $pizza = Pizza::where('id','=',$req->id)->get()->first();
        return view('deletePizza', compact('pizza'));
    }

    public function doDeletePizza(Request $req){
        $cart = Cart::where('pizza_id','=',$req->id)->first();
        $detail = Detail::where('pizza_id','=',$req->id)->first();

        if(!empty($cart) || !empty($detail))
            return back()->withErrors('Canot delete');

        Pizza::where('id','=',$req->id)->delete();
        return redirect('home');
    }
}
