<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth; 
use App\Cart;  
use App\Transaction; 
use App\Detail;

class TransactionController extends Controller
{ 
    public function insertTransaction(){   
        if (!Auth::check())
            return redirect('home'); 

        $currentUser = Auth::user(); 
        $currentUserId=$currentUser->id;  
         
        $userCarts = Cart::where('user_id','=',$currentUserId)->get();
        if($userCarts->first()==null)
            return redirect('home'); 
        
        $tempTransaction= new Transaction;
        $tempTransaction->user_id = $currentUserId; 
        $tempTransaction->save();
 
        foreach($userCarts as $userCart){
            $tempDetail= new Detail;
            $tempDetail->transaction_id = $tempTransaction->id; 
            $tempDetail->pizza_id = $userCart->pizza_id; 
            $tempDetail->quantity = $userCart->quantity;         
            $tempDetail->save();  
        }

        Cart::where('user_id','=',$currentUserId)->delete();
        return redirect('home'); 
    } 

    public function viewTransactionHistory(){       
        if (!Auth::check())
            return redirect('home'); 

        $currentUser = Auth::user(); 
        $currentUserId=$currentUser->id;   
         
        $listTransactions = Transaction::where('user_id','=',$currentUserId)->get();
  
        return view('viewTransactionHistory', compact('listTransactions'));
    }
    
    public function viewAllUserTransaction(){    
        if (!Auth::check())
            return redirect('home'); 
            
        $listTransactions = Transaction::get();
        return view('viewAllUserTransaction', compact('listTransactions'));
    }

    public function viewDetailTransaction(Request $req){  
        if (!Auth::check())
            return redirect('home'); 
            
        $currentUser = Auth::user();   
               
        $detailTransactions = Detail::where('transaction_id','=',$req->id)->get();
        if($detailTransactions!="[]" && $currentUser->role!="admin"){
            $transactionId = $detailTransactions->first()->transaction_id;
            $transactionUserId = Transaction::where('id','=',$transactionId)->first()->user_id;
            if($currentUser->id != $transactionUserId)
                return redirect('viewTransactionHistory'); 
        } 
 
        return view('viewDetailTransaction', compact( 'detailTransactions'));
    }
}
