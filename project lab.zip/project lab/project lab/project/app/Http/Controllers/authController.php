<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth; 
use Illuminate\Support\Facades\Cookie; 
use Illuminate\Support\Facades\DB; 
use App\Users;

class authController extends Controller
{
    public function loginPage(){  
        // kalau remember me pas buka page login langsung ke login
        if(cookie::get('id')){ 
            Auth::loginUsingId(cookie::get('id')); 
            return redirect('home'); 
        }  

        // kalau tidak remember me harus ketik email & pass 
        // $errors="";
        return view('login');
    }

    public function doLogin(Request $req){ 
        $this->Validate($req, [ 
            'email'=>'required',
            'password'=>'required', 
        ]);
         
        // kalau berhasil
        if(Auth::attempt(['email' => $req->email, 'password' => $req->password])){  
            // kalau remember me
            if($req->rememberMe){
               Cookie::queue('id', Auth::user()->id, 120); 
            }

            return redirect('home');
        }
        else{  // kalau salah pass/email
            $errors= collect(['Sorry your email or password not valid']); 
            return view('login', compact('errors'));
        } 
    } 

    public function forgotPasswordPage(){  
        if(cookie::get('id')){ 
            Auth::loginUsingId(cookie::get('id')); 
            return redirect('home'); 
        }  

        return view('forgotPassword');
    }

    public function doCheckEmail(Request $req){  
        $this->Validate($req, [ 
            'email'=>'required|email',
        ]);

        $user = Users::where('email','=', $req->email)->get(); 

        if($user=="[]")
            $errors= collect(['Email not found']); 
        else{
            $userEmail=$user->first()->email; 
            return redirect('forgotPassword/'.$userEmail);
        } 
        return view('forgotPassword', compact('errors'));
    }

    public function forgotPasswordFormPage(Request $req){
        $userEmail = $req->userEmail;

        return view('forgotPasswordForm', compact('userEmail'));
    }

    public function doChangePassword(Request $req){  
        $this->Validate($req, [ 
            'email'=>'required|email',
            'password'=>'required|min:6',
            'confirmPassword'=>'required|same:password',
        ]);

        $user = Users::where('email','=', $req->email)->get(); 

        if($user=="[]"){ 
            return back()->withErrors('Email not found');
        }
        
        $newPass = bcrypt($req->password);
        DB::update("update users set password = '$newPass' where email='$req->email'"); 
        
        return redirect('login');
    }
        
    public function doLogout(){ 
        Auth::logout();  
        return redirect('home')->withCookie(Cookie::forget('id'));;
    }

    public function registerPage(){ 
        // kalau remember me pas buka page login langsung ke login
        if(cookie::get('id')){ 
            Auth::loginUsingId(cookie::get('id')); 
            return redirect('home'); 
        }  

        // kalau tidak remember me harus ketik email & pass 
        return view('register');
    }

    public function doRegister(Request $req){  
        $this->Validate($req, [
            'username'=>'required',
            'email'=>'required',
        ]);

        $this->Validate($req, [ 
            'email'=>'required|email|unique:users',$req->email,
            'password'=>'required|min:6',
            'confirmPassword'=>'required|same:password',
            'address'=>'required',
            'phoneNumber'=>'required|numeric',
            'gender'=>'required|in:male,female',
        ]); 

        $tempUser = new Users;
        $tempUser->username = $req->username;
        $tempUser->email = $req->email;
        $tempUser->password = bcrypt($req->password);
        $tempUser->address = $req->address;
        $tempUser->phoneNumber = $req->phoneNumber;
        $tempUser->gender = $req->gender;
        $tempUser->role = "member";
        $tempUser->save();
         
        return redirect('login'); 
    }
}
