<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Transaction;  
use App\Pizza;  

class Detail extends Model
{
    protected $fillable = [];
    
    public function transaction(){
        return $this->belongsToMany(Transaction::class);
    } 

    public function pizza(){
        return $this->hasMany(Pizza ::class, 'id', 'pizza_id');
    } 
}
