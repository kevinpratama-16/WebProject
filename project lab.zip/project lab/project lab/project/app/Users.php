<?php

namespace App;
use Illuminate\Foundation\Auth\User as Authenticatable; 
use Illuminate\Database\Eloquent\Model;

class Users extends Authenticatable
{
    protected $fillable = [];

    public function cart(){
        return $this->hasMany(Cart::class, 'user_id', 'id');
    }
    
    public function transaction(){
        return $this->belongsToMany(Transaction ::class);
    }
}
