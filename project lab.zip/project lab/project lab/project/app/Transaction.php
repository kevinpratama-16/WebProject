<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Users;  
use App\Detail;  

class Transaction extends Model
{
    protected $fillable = []; 
    
    public function users(){
        return $this->hasMany(Users::class, 'id', 'user_id');
    } 

    public function detail(){
        return $this->hasMany(Detail::class, 'transaction_id', 'id');
    }
}
