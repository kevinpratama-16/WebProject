<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\User;  
use App\Pizza;  

class Cart extends Model
{ 
    protected $fillable = []; 
    
    public function user(){
        return $this->belongsToMany(User::class);
    } 

    public function pizza(){
        return $this->hasMany(Pizza ::class, 'id', 'pizza_id');
    } 
}
