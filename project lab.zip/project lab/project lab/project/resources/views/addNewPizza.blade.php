@section('cssPage')
    <link rel="stylesheet" href="{{asset('css/addNewPizza.css')}}">
@endsection

@extends('template')

@section('contentWrapper')
    <div class="content">
        <div class="addNewPizzaTitle">
            Add New Pizza
        </div>
        @if($errors->first()!="")
            <div class="errorMessage">
                {{$errors->first()}}
            </div>       
        @endif  
        <form action="{{ url('/addNewPizza') }}" method="POST" class="formDetail" enctype="multipart/form-data"> 
            @csrf 
            <span>Pizza Name</span>
            <input class="imputData" type="text" name="pizzaName" placeholder="Pizza Name">  
            <span>Pizza Price</span>
            <input class="imputData" type="text" name="pizzaPrice" placeholder="Pizza Price">  
            <span>Pizza Description</span>
            <input class="imputData" type="text" name="pizzaDescription" placeholder="Pizza Description">  
            <span>Pizza Image</span>
            <input class="imputFile" type="file" name="pizzaImage">   
            <input type="submit" value="Add Pizza" class="submitButon">  
        </form>   
    </div> 
@endsection