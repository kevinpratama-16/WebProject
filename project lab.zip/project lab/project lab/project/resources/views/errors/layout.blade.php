<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="{{asset('css/errors.css')}}"> 
        <title>@yield('title')</title>
    </head>
    <body> 
        <div class="wrapper"> 
            <div class="text">
                @yield('message')
            </div>
            <a href="{{ url('/') }}" class="buton">     
                Home
            </a>
        </div>   
    </body>    
</html>
