@section('cssPage') 
    <link rel="stylesheet" href={{asset('css/viewCart.css')}}>
@endsection

@extends('template')

@section('contentWrapper') 
    <div class="content"> 
        <div class="titlePage">
            Transaction Detail
        </div>  

        @if($detailTransactions->first() == null)
            <div class="noData">
                Transaction not found
            </div>
        @endif  
        @foreach($detailTransactions as $detailTransaction)
            <div class="cartWrapper">
                <div class="image">
                    <img src="{{asset('storage/'.$detailTransaction->pizza->first()->image)}}" height="100%" width="400">
                </div>
                <div class="desciption">  
                    <div class="title">
                        {{$detailTransaction->pizza->first()->name}}
                    </div>
                    <div class="detail">
                        <div>Price </div>
                        <div>Rp. {{$detailTransaction->pizza->first()->price}}</div>
                        <div>Quantity</div>
                        <div>{{$detailTransaction->quantity}}</div> 
                        <div>Total Price</div>
                        <div>Rp. {{$detailTransaction->pizza->first()->price*$detailTransaction->quantity}}</div>
                    </div>  
                </div>
            </div> 
        @endforeach
    </div> 
@endsection