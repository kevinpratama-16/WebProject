@section('cssPage')
    <link rel="stylesheet" href="css/login.css">
@endsection

@extends('template')

@section('contentWrapper')
    <div class="content">
        <div class="loginTitle">
            Forgot Password
        </div>
        @if(!$errors->isEmpty())
            <div class="errorMessage">
                {{$errors->first()}}
            </div>       
        @endif  
        <form action="{{ url('/forgotPasswordForm') }}" method="POSt" class="loginDetail"> 
            @csrf 
            <input class="imputData" type="text" name="email" value={{$userEmail}}>  
            <input class="imputDataForgot" type="password" name="password" placeholder="Password">  
            <input class="imputDataForgot" type="password" name="confirmPassword" placeholder="Password">
             
            <div class="loginButom">
                <input type="submit" value="Change Password" class="submitButon">
            </div>
        </form>   
    </div> 
@endsection