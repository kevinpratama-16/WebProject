<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="{{asset('css/headerFooter.css')}}"> 
    @yield('cssPage')
    <title>Phizaa Hut</title>
</head>
<body>
    <div class="header"> 
        <a href="{{ url('/') }}"  class="headerLogoWrapper">
            <img src="{{asset('storage/img/logo.png')}}" class="headerLogo"> 
            <div class="headerLogoText">
                PHizza Hut
            </div> 
        </a>
        <div class="headerButtonWrapper"> 
            @if(!Illuminate\Support\Facades\Auth::check())
                <a href="{{ url('register') }}" class="headerButtom">
                    Register 
                </a>
                <a href="{{ url('login') }}" class="headerButtom"> 
                    Login 
                </a>
            @elseif(Illuminate\Support\Facades\Auth::User()->role == "member")
                <div class="headerDropdownWrapper">
                    <div class="headerDropdownUsername">
                        {{Illuminate\Support\Facades\Auth::User()->username}}
                        <img src="{{asset('storage/img/dropdown.png')}}" height="12px" width="auto">
                    </div>
                    <div class="headerDropdownList">
                        <a href="{{ url('logout') }}" class="headerDropdownListItem">Logout</a>
                    </div>
                </div>           
                <a href="{{ url('viewCart') }}" class="headerButtom">     
                    View Cart 
                </a>
                <a href="{{ url('viewTransactionHistory') }}" class="headerButtom"> 
                    View Transaction History 
                </a> 
            @elseif(Illuminate\Support\Facades\Auth::User()->role == "admin")
                <div class="headerDropdownWrapper">
                    <div class="headerDropdownUsername">
                        {{Illuminate\Support\Facades\Auth::User()->username}}
                        <img src="{{asset('storage/img/dropdown.png')}}" height="12px" width="auto">
                    </div>
                    <div class="headerDropdownList">
                        <a href="{{ url('logout') }}" class="headerDropdownListItem">Logout</a>
                    </div>
                </div>
                <a href="{{ url('viewAllUser') }}" class="headerButtom"> 
                        View All User 
                </a>
                <a href="{{ url('viewAllUserTransaction') }}" class="headerButtom"> 
                    View All User Transaction 
                </a>   
            @endif
        </div> 
    </div>
    @yield('contentWrapper')  
</body>
</html>