@section('cssPage')
    <link rel="stylesheet" href="css/login.css">
@endsection

@extends('template')

@section('contentWrapper')
    <div class="content">
        <div class="loginTitle">
            Forgot Password
        </div>
        @if(!$errors->isEmpty())
            <div class="errorMessage">
                {{$errors->first()}}
            </div>       
        @endif  
        <form action="{{ url('forgotPassword') }}" method="post" class="loginDetail"> 
            @csrf 
            <input class="imputData" type="text" name="email" placeholder="E-mail Address">   
            <div class="loginButom">
                <input type="submit" value="Check Email" class="submitButon"> 
            </div>
        </form>   
    </div> 
@endsection