@section('cssPage')
    <link rel="stylesheet" href={{asset('css/pizzaDetail.css')}}>
@endsection

@extends('template')

@section('contentWrapper') 
    <div class="content">  
        <img class="pizzaImage" src="{{asset('storage/'.$pizza->image)}}"> 
        <div class="pizzaDetail">         
            <div class="pizzaTitle">
                {{$pizza->name}} 
            </div>
            <div class="pizzaDescription">
                {{$pizza->description}}
            </div>
            <div class="pizzaPrice">
                Rp. {{$pizza->price}}
            </div>
            @if(Illuminate\Support\Facades\Auth::check() && Illuminate\Support\Facades\Auth::User()->role == "member") 
                @if(!$errors->isEmpty())
                    <div class="errorMessage">
                        {{$errors->first()}}
                    </div>       
                @endif      
                <form action="{{ url('addToCart/'.$pizza->id) }}" method="POST" style="display: flex;"> 
                    @csrf 
                    <div class="textQuantity">Quantity </div>
                    <input class="imputData" type="text" name="pizzaQuantity">  
                    <input type="submit" value="Add to Cart" class="submitButon"> 
                </form> 
            @endif
        </div>
    </div> 
@endsection