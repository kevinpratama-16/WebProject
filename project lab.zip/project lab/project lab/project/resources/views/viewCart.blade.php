@section('cssPage') 
    <link rel="stylesheet" href={{asset('css/viewCart.css')}}>
@endsection

@extends('template')

@section('contentWrapper') 
    <div class="content"> 
        <div class="titlePage">
            Cart
        </div>
        @if(!$errors->isEmpty())
            <div class="errorMessage">
                {{$errors->first()}}
            </div>       
        @endif   
        @if($listCarts->isEmpty())
            <div class="noData">
                There is No data
            </div>
        @else
            <a href="{{ url('insertTransaction') }}">  
                <div class="checkOutButtom">
                    Check Out
                </div>   
            </a>
        @endif
        @foreach($listCarts as $listCart)
            <div class="cartWrapper">
                <div class="image">
                    <img src="{{asset('storage/'.$listCart->pizza->first()->image)}}" height="100%" width="400">
                </div>
                <div class="desciption"> 
                    <a href="{{ url('removeCart/'.$listCart->pizza->first()->id) }}" class="deleteButton"> 
                        <img src="{{asset('storage/img/trash.png')}}" height="30px" width="30px">
                    </a>
                    <div class="title">
                        {{$listCart->pizza->first()->name}}
                    </div>
                    <div class="detail">
                        <div>Price </div>
                        <div>Rp. {{$listCart->pizza->first()->price}}</div>
                        <div>Quantity</div>
                        <div>{{$listCart->quantity}}</div>  
                    </div> 
                    <form action="{{ url('updateQuantity/'.$currentUserId.'/'.$listCart->pizza->first()->id) }}" method="POST" style="display: flex;"> 
                        @csrf 
                        <div class="textQuantity">Quantity </div>
                        <input class="imputData" type="text" name="pizzaQuantity">  
                        <input type="submit" value="Update Quantity" class="submitButon"> 
                    </form> 
                </div>
            </div>
        @endforeach  
    </div> 
@endsection