@section('cssPage')
    <link rel="stylesheet" href="{{asset('css/home.css')}}"> 
@endsection

@extends('template')

@section('contentWrapper')
    <div class="content"> 
        <div class="title">
           Our freshly made pizza!
        </div>
        <div class="subTitle">
            Order it now!
        </div> 
        @if(Illuminate\Support\Facades\Auth::check() && Illuminate\Support\Facades\Auth::User()->role == "admin")
            <a href="{{ url('addNewPizza') }}"> 
                <div class="addPizzaButton">
                    Add New Pizza
                </div> 
            </a> 
        @else
            <form action="{{ url('searchPizza') }}" style="display: inline"> 
                @csrf   
                <div class="textSearch">Search Pizza</div>
                @if($searchKey=="")
                    <input class="imputData" type="text" name="pizzaName" placeHolder="Search Some Pizza">  
                @else
                    <input class="imputData" type="text" name="pizzaName" value="{{$searchKey}}">  
                @endif
                <input type="submit" value="Search" class="submitButon"> 
            </form>  
        @endif    

        <div class="displayPizza"> 
            @if($listPizzas->isEmpty())
                <div class="notFound">
                    Sorry there is no pizza
                </div>
            @endif
            @foreach($listPizzas as $listPizza)
                <div class="pizzaWrapper">  
                    <a href="{{ url('pizzaDetail/'.$listPizza->id) }}">                       
                        <img class="pizzaImage" src="{{asset('storage/'.$listPizza->image)}}" >
                        <div class="pizzaTitle">                       
                            {{$listPizza->name}}
                        </div> 
                        <div class="pizzaPrice">
                            Rp. {{$listPizza->price}}
                        </div>  
                        @if(Illuminate\Support\Facades\Auth::check() && Illuminate\Support\Facades\Auth::User()->role == "admin") 
                            <div class="pizzaButtonWrapper">
                                 
                                <a href="{{ url('updatePizza/'.$listPizza->id) }}">
                                    <div class="pizzaButton">
                                        Update Pizza
                                    </div> 
                                </a> 
                                <a href="{{ url('deletePizza/'.$listPizza->id) }}">
                                    <div class="pizzaButton">
                                        Delete Pizza
                                    </div> 
                                </a> 
                            </div>
                        @endif
                    </a>  
                </div> 
            @endforeach
        </div>
        <div class="pagination">
            {{$listPizzas->links()}}   
        </div>
    </div> 
@endsection