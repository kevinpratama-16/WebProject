@section('cssPage')
    <link rel="stylesheet" href="css/viewAllUser.css">
@endsection

@extends('template')

@section('contentWrapper') 
    <div class="content">  
        @foreach ($users as $user) 
            <div class="userWrapper">
                <div class="userId">
                    User ID : {{$user->id}}
                </div>
                <div class="firstUserData">
                    Username : {{$user->username}}
                </div>
                <div class="userData">
                    Email : {{$user->email}}
                </div>
                <div class="userData">
                    Address : {{$user->address}}
                </div>
                <div class="userData">
                    Phone : {{$user->phoneNumber}}
                </div>
                <div class="userData">
                    Gender : {{$user->gender}}
                </div>
            </div>  
        @endforeach
    </div> 
@endsection