@section('cssPage')
    <link rel="stylesheet" href="css/register.css">
@endsection

@extends('template')

@section('contentWrapper')
    <div class="content">
        <div class="registerTitle">
            Register
        </div>
        @if($errors->first()!="")
            <div class="errorMessage">
                {{$errors->first()}}
            </div>       
        @endif  
        <form action="{{ url('/register') }}" method="POST" class="registerDetail"> 
            @csrf 
            <input class="imputData" type="text" name="username" placeholder="Username">  
            <input class="imputData" type="text" name="email" placeholder="E-mail Address">  
            <input class="imputData" type="password" name="password" placeholder="Password">  
            <input class="imputData" type="password" name="confirmPassword" placeholder="Confirm Password">  
            <input class="imputData" type="text" name="address" placeholder="Address">  
            <input class="imputData" type="text" name="phoneNumber" placeholder="phoneNumber">  
            Gender
            <input class="imputRadio" type="radio" name="gender" value="male"> Male
            <input class="imputRadio" type="radio" value="female" name="gender"> Female<br>
            <div class="registerButom">
                <input type="submit" value="Register" class="submitButon"> 
            </div>
        </form>   
    </div> 
@endsection