@section('cssPage')
    <link rel="stylesheet" href="css/viewAllUser.css">
@endsection

@extends('template')

@section('contentWrapper') 
    <div class="content">  
        @foreach ($listTransactions as $listTransaction) 
            <a href="{{ url('viewDetailTransaction/'.$listTransaction->id) }}"> 
                <div class="userWrapper">
                    <div class="transactionDate">
                        Transaction at {{$listTransaction->created_at}}
                    </div>
                    <div class="firstUserData">
                        Username : {{$listTransaction->users->first()->username}}
                    </div>
                    <div class="userData">
                        User ID : {{$listTransaction->user_id}}
                    </div> 
                </div>  
            </a>
        @endforeach
    </div> 
@endsection