@section('cssPage')
    <link rel="stylesheet" href="{{asset('css/pizzaDetail.css')}}">
@endsection

@extends('template')

@section('contentWrapper')    
    <div class="content">  
        <img class="pizzaImage" src="{{asset('storage/'.$pizza->image)}}"> 
        <div class="pizzaDetail">         
            <div class="pizzaTitle">
                {{$pizza->name}} 
            </div>
            <div class="pizzaDescription">
                {{$pizza->description}}
            </div>
            <div class="pizzaPrice">
                Rp. {{$pizza->price}}
            </div> 
            @if(!$errors->isEmpty())
            <div class="errorMessage">
                {{$errors->first()}}
            </div>       
        @endif
            <a href="{{ url('doDeletePizza/'.$pizza->id) }}">
                <div class="deleteButton">
                    Delete Pizza
                </div> 
            </a>            
        </div>
    </div> 
@endsection 