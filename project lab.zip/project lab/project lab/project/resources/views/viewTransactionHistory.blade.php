@section('cssPage') 
    <link rel="stylesheet" href={{asset('css/viewTransactionHistory.css')}}>
@endsection

@extends('template')

@section('contentWrapper') 
    <div class="content"> 
        <div class="titlePage">
            View Transaction History
        </div> 
 
        @if($listTransactions->isEmpty())
            <div class="noData">
                There is No data
            </div> 
        @endif 
 
        @foreach($listTransactions as $listTransaction) 
            <a href="{{ url('viewDetailTransaction/'.$listTransaction->id) }}"> 
                <div class="transaction"> 
                    Transaction at {{$listTransaction->created_at}}
                </div>                
            </a>
        @endforeach  
    </div> 
@endsection