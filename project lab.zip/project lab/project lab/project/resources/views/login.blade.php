@section('cssPage')
    <link rel="stylesheet" href="css/login.css">
@endsection

@extends('template')

@section('contentWrapper')
    <div class="content">
        <div class="loginTitle">
            Login
        </div>
        @if(!$errors->isEmpty())
            <div class="errorMessage">
                {{$errors->first()}}
            </div>       
        @endif  
        <form action="{{ url('/login') }}" method="POSt" class="loginDetail"> 
            @csrf 
            <input class="imputData" type="text" name="email" placeholder="E-mail Address">  
            <input class="imputData" type="password" name="password" placeholder="Password">  
            <div class="checkBox">
                <input type="checkbox" name="rememberMe"> Remember Me 
            </div>
            <div class="loginButom">
                <input type="submit" value="Login" class="submitButon">
                <a href="{{ url('/forgotPassword') }}">Forgot Password</a>
            </div>
        </form>   
    </div> 
@endsection