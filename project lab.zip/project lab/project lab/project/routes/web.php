<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'pizzaController@homePage');  
Route::get('home', 'pizzaController@homePage');   
Route::get('searchPizza', 'pizzaController@searchPizza')->middleware('checkIsNotAdmin');; 

Route::get('login', 'authController@loginPage')->middleware('checkIsNotLogin');   
Route::post('login', 'authController@doLogin')->middleware('checkIsNotLogin');      

Route::get('forgotPassword', 'authController@forgotPasswordPage')->middleware('checkIsNotLogin');   
Route::post('forgotPassword', 'authController@doCheckEmail')->middleware('checkIsNotLogin');      
Route::get('forgotPassword/{userEmail}', 'authController@forgotPasswordFormPage')->middleware('checkIsNotLogin');      
Route::post('forgotPasswordForm', 'authController@doChangePassword')->middleware('checkIsNotLogin');      


Route::get('logout', 'authController@doLogout');   

Route::get('register', 'authController@registerPage')->middleware('checkIsNotLogin');    
Route::post('register', 'authController@doRegister')->middleware('checkIsNotLogin');   

Route::get('viewAllUser', 'userController@viewAllUser')->middleware('checkIsAdmin');  


Route::get('pizzaDetail/{id}', 'pizzaController@pizzaDetail');  

Route::post('addToCart/{pizzaId}', 'cartController@addToCart')->middleware('checkIsMember');; 

Route::post('updateQuantity/{id}/{pizzaId}', 'cartController@updateQuantity')->middleware('checkIsMember');; 

Route::get('removeCart/{pizzaId}', 'cartController@removeCart')->middleware('checkIsMember');; 

Route::get('viewCart', 'cartController@viewCart')->middleware('checkIsMember');; 


Route::get('insertTransaction', 'TransactionController@insertTransaction')->middleware('checkIsMember');; 

Route::get('viewTransactionHistory', 'TransactionController@viewTransactionHistory')->middleware('checkIsMember');; 

Route::get('viewAllUserTransaction', 'TransactionController@viewAllUserTransaction')->middleware('checkIsAdmin');; 

Route::get('viewDetailTransaction/{id}', 'TransactionController@viewDetailTransaction')->middleware('checkIsLogin');; 


Route::get('deletePizza/{id}', 'pizzaController@deletePizzaPage')->middleware('checkIsAdmin');    
Route::get('doDeletePizza/{id}', 'pizzaController@doDeletePizza')->middleware('checkIsAdmin'); 

Route::get('addNewPizza', 'pizzaController@addNewPizzaPage')->middleware('checkIsAdmin');    
Route::post('addNewPizza', 'pizzaController@doAddNewPizza')->middleware('checkIsAdmin');    

Route::get('updatePizza/{id}', 'pizzaController@updatePizzaPage')->middleware('checkIsAdmin');    
Route::post('updatePizza/{id}', 'pizzaController@doUpdatePizza')->middleware('checkIsAdmin');    
