<?php

use Illuminate\Database\Seeder;

class CartSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('carts')->insert([
            'user_id' => '2',
            'pizza_id' => '4',
            'quantity' => 1, 
        ]); 
        DB::table('carts')->insert([
            'user_id' => '1',
            'pizza_id' => '7',
            'quantity' => 2, 
        ]);
        DB::table('carts')->insert([
            'user_id' => '2',
            'pizza_id' => '3',
            'quantity' => 1, 
        ]);
        DB::table('carts')->insert([
            'user_id' => '2',
            'pizza_id' => '1',
            'quantity' => 1, 
        ]);
        DB::table('carts')->insert([
            'user_id' => '4',
            'pizza_id' => '3',
            'quantity' => 4, 
        ]);
        DB::table('carts')->insert([
            'user_id' => '1',
            'pizza_id' => '1',
            'quantity' => 3, 
        ]);
    }
}
