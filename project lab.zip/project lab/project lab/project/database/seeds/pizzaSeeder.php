<?php

use Illuminate\Database\Seeder;

class pizzaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('pizzas')->insert([
            'name' => 'Pepperoni Pizza',
            'description' => 'Green Peppers,Pepperoni,Mushrooms,Onions,Cheese',
            'price' => 120000,
            'image' => 'img/pizza1.jpg',
        ]);

        DB::table('pizzas')->insert([
            'name' => 'Italian Pizza',
            'description' => 'Red Peppers,Yellow Peppers,Basil Leaves,Mushrooms,Cheeses',
            'price' => 150000,
            'image' => 'img/pizza2.jpg',
        ]);

        DB::table('pizzas')->insert([
            'name' => 'Cheesy Meatlovers',
            'description' => 'Sausages,Pepperonis,Mushrooms,Cheeses',
            'price' => 200000,
            'image' => 'img/pizza3.jpg',
        ]);

        DB::table('pizzas')->insert([
            'name' => 'Pizza4',
            'description' => 'Red Peppers,Yellow Peppers,Basil Leaves,Mushrooms,Cheeses',
            'price' => 150000,
            'image' => 'img/pizza4.jpg',
        ]);
 
        DB::table('pizzas')->insert([
            'name' => 'Pizza5',
            'description' => 'Sausages,Pepperonis,Mushrooms,Cheeses',
            'price' => 200000,
            'image' => 'img/pizza3.jpg',
        ]);
        
        DB::table('pizzas')->insert([
            'name' => 'Pizza6',
            'description' => 'Green Peppers,Pepperoni,Mushrooms,Onions,Cheese',
            'price' => 120000,
            'image' => 'img/pizza1.jpg',
        ]);

        DB::table('pizzas')->insert([
            'name' => 'Pizza7',
            'description' => 'Red Peppers,Yellow Peppers,Basil Leaves,Mushrooms,Cheeses',
            'price' => 150000,
            'image' => 'img/pizza2.jpg',
        ]);
    }
}
