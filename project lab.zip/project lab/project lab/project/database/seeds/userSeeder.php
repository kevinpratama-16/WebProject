<?php

use Illuminate\Database\Seeder;

class userSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {         
        DB::table('users')->insert([
            'username' => 'User Member',
            'email' => 'member@gmail.com',
            'password' => bcrypt('member'),
            'address' => 'Rumah',
            'phoneNumber' => '011836402233',
            'gender' => 'Male',
            'role' => 'member',
        ]); 
        DB::table('users')->insert([
            'username' => 'Member Member',
            'email' => 'member@yahoo.com',
            'password' => bcrypt('memberMember'),
            'address' => 'Jalan Mawar',
            'phoneNumber' => '0218828382',
            'gender' => 'Female',
            'role' => 'member',
        ]); 
        DB::table('users')->insert([
            'username' => 'admin123',
            'email' => 'admin@gmail.com',
            'password' => bcrypt('admin'),
            'address' => 'Alamat Rumah',
            'phoneNumber' => '0816311122121',
            'gender' => 'male',
            'role' => 'admin',
        ]);
        DB::table('users')->insert([
            'username' => 'member88',
            'email' => 'member123@gmail.com',
            'password' => bcrypt('member'),
            'address' => 'Jalan 1',
            'phoneNumber' => '081366284927',
            'gender' => 'Female',
            'role' => 'member',
        ]); 
    }
}
