<?php

use Illuminate\Database\Seeder;

class detailSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    { 
        DB::table('details')->insert([
            'transaction_id' => '1', 
            'pizza_id' => '4', 
            'quantity' => '2', 
        ]);
        DB::table('details')->insert([
            'transaction_id' => '1', 
            'pizza_id' => '2', 
            'quantity' => '1', 
        ]);
        DB::table('details')->insert([
            'transaction_id' => '2', 
            'pizza_id' => '7', 
            'quantity' => '4', 
        ]);

        DB::table('details')->insert([
            'transaction_id' => '3', 
            'pizza_id' => '5', 
            'quantity' => '1', 
        ]);
        DB::table('details')->insert([
            'transaction_id' => '3', 
            'pizza_id' => '1', 
            'quantity' => '1', 
        ]);
        DB::table('details')->insert([
            'transaction_id' => '3', 
            'pizza_id' => '4', 
            'quantity' => '3', 
        ]);
        DB::table('details')->insert([
            'transaction_id' => '4', 
            'pizza_id' => '6', 
            'quantity' => '4', 
        ]); 
        DB::table('details')->insert([
            'transaction_id' => '5', 
            'pizza_id' => '2', 
            'quantity' => '1', 
        ]);
        DB::table('details')->insert([
            'transaction_id' => '5', 
            'pizza_id' => '1', 
            'quantity' => '1', 
        ]); 
    }
}
