<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/headerFooter.css">
    <link rel="stylesheet" href="css/login.css">
    <title>Login</title>
</head>
<body>
    <div class="header"> 
        <a href="<?php echo e(url('/')); ?>"  class="headerLogoWrapper">
            <img src="<?php echo e(asset('storage/img/logo.png')); ?>" class="headerLogo"> 
            <div class="headerLogoText">
                PHizza Hut
            </div> 
        </a>
        
        <div class="headerButtonWrapper"> 
            <div class="headerButtom">
                <a href="<?php echo e(url('register')); ?>">Register</a>
            </div>
            <div class="headerButtom">
                <a href="<?php echo e(url('login')); ?>">Login</a>
            </div> 
        </div> 
    </div>
    <div class="content">
        <div class="loginTitle">
            Login
        </div>
        <?php if($errors->first()!=""): ?>
            <div class="errorMessage">
                <?php echo e($errors->first()); ?>

            </div>       
        <?php endif; ?>  
        <form action="<?php echo e(url('/login')); ?>" method="POSt" class="loginDetail"> 
            <?php echo csrf_field(); ?> 
            <input class="imputData" type="text" name="email" placeholder="E-mail Address">  
            <input class="imputData" type="password" name="password" placeholder="Password">  
            <div class="checkBox">
                <input type="checkbox" name="rememberMe"> Remember Me 
            </div>
            <div class="loginButom">
                <input type="submit" value="Login" class="submitButon">
                <a href="">Forgot Password</a>
            </div>
        </form>   
    </div> 
</body>
</html><?php /**PATH D:\TUGAS\Semester 5\Web Lab\project\project\resources\views/login.blade.php ENDPATH**/ ?>