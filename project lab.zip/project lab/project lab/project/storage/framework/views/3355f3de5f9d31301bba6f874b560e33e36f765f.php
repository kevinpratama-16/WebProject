<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/headerFooter.css')); ?>"> 
    <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">
    <title>Home</title>
</head>
<body>
    <div class="header"> 
        <a href="<?php echo e(url('/')); ?>"  class="headerLogoWrapper">
            <img src="<?php echo e(asset('storage/img/logo.png')); ?>" class="headerLogo"> 
            <div class="headerLogoText">
                PHizza Hut
            </div> 
        </a>
        <div class="headerButtonWrapper"> 
            <?php if($currentRole == "member"): ?>
                <div class="headerDropdownWrapper">
                    <div class="headerDropdownUsername">
                        <?php echo e($currentUsername); ?>

                        <img src="<?php echo e(asset('storage/img/dropdown.png')); ?>" height="12px" width="auto">
                    </div>
                    <div class="headerDropdownList">
                        <a href="<?php echo e(url('logout')); ?>" class="headerDropdownListItem">Logout</a>
                    </div>
                </div>                    
                <div class="headerButtom">
                    <a href="">View Cart</a>
                </div>
                <div class="headerButtom">
                    <a href="">View Transaction History</a>
                </div>
            <?php elseif($currentRole == "admin"): ?>
                <div class="headerDropdownWrapper">
                    <div class="headerDropdownUsername">
                        <?php echo e($currentUsername); ?>

                        <img src="<?php echo e(asset('storage/img/dropdown.png')); ?>" height="12px" width="auto">
                    </div>
                    <div class="headerDropdownList">
                        <a href="<?php echo e(url('logout')); ?>" class="headerDropdownListItem">Logout</a>
                    </div>
                </div>
                <div class="headerButtom">
                    <a href="viewAllUser">View All User</a>
                </div>
                <div class="headerButtom">
                    <a href="">View All User Transaction</a>
                </div>
            <?php else: ?>
                <div class="headerButtom">
                    <a href="<?php echo e(url('register')); ?>">Register</a>
                </div>
                <div class="headerButtom">
                    <a href="<?php echo e(url('login')); ?>">Login</a>
                </div>
            <?php endif; ?>
        </div> 
    </div>
    <div class="content"> 
        <div class="title">
           Our freshly made pizza!
        </div>
        <div class="subTitle">
            Order it now!
        </div> 
        <?php if($currentRole == "admin"): ?>
            <a href="<?php echo e(url('addNewPizza')); ?>"> 
                <div class="addPizzaButton">
                    Add New Pizza
                </div> 
            </a> 
        <?php else: ?>
            <form action="<?php echo e(url('searchPizza')); ?>" style="display: inline"> 
                <?php echo csrf_field(); ?> 
                <div class="textSearch">Search Pizza</div>
                <input class="imputData" type="text" name="pizzaName" placeholder="Search Here">  
                <input type="submit" value="Search" class="submitButon"> 
            </form>  
        <?php endif; ?>    

        <div class="displayPizza"> 
            <?php if($listPizzas->isEmpty()): ?>
                <div class="notFound">
                    Sorry there is no pizza
                </div>
            <?php endif; ?>
            <?php $__currentLoopData = $listPizzas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listPizza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="pizzaWrapper">  
                    <a href="<?php echo e(url('pizzaDetail/'.$listPizza->id)); ?>">                       
                        <img class="pizzaImage" src="<?php echo e(asset('storage/'.$listPizza->image)); ?>" >
                        <div class="pizzaTitle">                       
                            <?php echo e($listPizza->name); ?>

                        </div> 
                        <div class="pizzaPrice">
                            Rp. <?php echo e($listPizza->price); ?>

                        </div>  
                        <?php if($currentRole == "admin"): ?> 
                            <div class="pizzaButtonWrapper">
                                 
                                <a href="<?php echo e(url('')); ?>">
                                    <div class="pizzaButton">
                                        Update Pizza
                                    </div> 
                                </a> 
                                <a href="<?php echo e(url('deletePizza/'.$listPizza->id)); ?>">
                                    <div class="pizzaButton">
                                        Delete Pizza
                                    </div> 
                                </a> 
                            </div>
                        <?php endif; ?>
                    </a>  
                </div> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div style="margin-bottom:60px;">
            <?php echo e($listPizzas->links()); ?>   
        </div>
    </div> 
</body>
</html><?php /**PATH D:\TUGAS\Semester 5\Web Lab\project\project\resources\views/home.blade.php ENDPATH**/ ?>