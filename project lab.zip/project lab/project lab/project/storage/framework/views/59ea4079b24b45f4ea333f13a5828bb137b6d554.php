<?php $__env->startSection('cssPage'); ?> 
    <link rel="stylesheet" href=<?php echo e(asset('css/viewCart.css')); ?>>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('contentWrapper'); ?> 
    <div class="content"> 
        <div class="titlePage">
            Transaction Detail
        </div>  

        <?php if($detailTransactions->first() == null): ?>
            <div class="noData">
                Transaction not found
            </div>
        <?php endif; ?>  
        <?php $__currentLoopData = $detailTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detailTransaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="cartWrapper">
                <div class="image">
                    <img src="<?php echo e(asset('storage/'.$detailTransaction->pizza->first()->image)); ?>" height="100%" width="400">
                </div>
                <div class="desciption">  
                    <div class="title">
                        <?php echo e($detailTransaction->pizza->first()->name); ?>

                    </div>
                    <div class="detail">
                        <div>Price </div>
                        <div>Rp. <?php echo e($detailTransaction->pizza->first()->price); ?></div>
                        <div>Quantity</div>
                        <div><?php echo e($detailTransaction->quantity); ?></div> 
                        <div>Total Price</div>
                        <div>Rp. <?php echo e($detailTransaction->pizza->first()->price*$detailTransaction->quantity); ?></div>
                    </div>  
                </div>
            </div> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS\Semester 5\Web Lab\project lab\project\resources\views/viewDetailTransaction.blade.php ENDPATH**/ ?>