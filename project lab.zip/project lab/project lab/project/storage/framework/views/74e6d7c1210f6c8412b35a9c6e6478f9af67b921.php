<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/headerFooter.css">
    <link rel="stylesheet" href="css/viewAllUser.css">
    <title>View All User</title>
</head>
<body>
    <div class="header"> 
        <a href="<?php echo e(url('/')); ?>"  class="headerLogoWrapper">
            <img src="<?php echo e(asset('storage/img/logo.png')); ?>" class="headerLogo"> 
            <div class="headerLogoText">
                PHizza Hut
            </div> 
        </a>
        <div class="headerButtonWrapper">  
            <div class="headerDropdownWrapper">
                <div class="headerDropdownUsername">
                    <?php echo e($currentUsername); ?>

                    <img src="<?php echo e(asset('storage/img/dropdown.png')); ?>" height="12px" width="auto">
                </div>
                <div class="headerDropdownList">
                    <a href="<?php echo e(url('logout')); ?>" class="headerDropdownListItem">Logout</a>
                </div>
            </div>
            <div class="headerButtom">
                <a href="viewAllUser">View All User</a>
            </div>
            <div class="headerButtom">
                <a href="">View All User Transaction</a>
            </div> 
        </div> 
    </div>
    <div class="content">  
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <div class="userWrapper">
                <div class="userId">
                    User ID : <?php echo e($user->id); ?>

                </div>
                <div class="firstUserData">
                    Username : <?php echo e($user->username); ?>

                </div>
                <div class="userData">
                    Email : <?php echo e($user->email); ?>

                </div>
                <div class="userData">
                    Address : <?php echo e($user->address); ?>

                </div>
                <div class="userData">
                    Phone : <?php echo e($user->phoneNumber); ?>

                </div>
                <div class="userData">
                    Gender : <?php echo e($user->gender); ?>

                </div>
            </div>  
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div> 
</body>
</html><?php /**PATH D:\TUGAS\Semester 5\Web Lab\project\project\resources\views/viewAllUser.blade.php ENDPATH**/ ?>