<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo e(asset('css/errors.css')); ?>"> 
        <title><?php echo $__env->yieldContent('title'); ?></title> 
    </head>
    <body>
        <div class="wrapper"> 
            <div class="text">
                <?php echo $__env->yieldContent('code'); ?> <?php echo $__env->yieldContent('message'); ?>
            </div>
            <a href="<?php echo e(url('/')); ?>" class="buton">     
                Home
            </a>
        </div>        
        
    </body>
</html>
<?php /**PATH D:\TUGAS\Semester 5\Web Lab\project lab\project\resources\views/errors/minimal.blade.php ENDPATH**/ ?>