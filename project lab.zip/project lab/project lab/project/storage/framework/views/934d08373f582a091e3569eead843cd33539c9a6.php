<?php $__env->startSection('cssPage'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>"> 
<?php $__env->stopSection(); ?>



<?php $__env->startSection('contentWrapper'); ?>
    <div class="content"> 
        <div class="title">
           Our freshly made pizza!
        </div>
        <div class="subTitle">
            Order it now!
        </div> 
        <?php if(Illuminate\Support\Facades\Auth::check() && Illuminate\Support\Facades\Auth::User()->role == "admin"): ?>
            <a href="<?php echo e(url('addNewPizza')); ?>"> 
                <div class="addPizzaButton">
                    Add New Pizza
                </div> 
            </a> 
        <?php else: ?>
            <form action="<?php echo e(url('searchPizza')); ?>" style="display: inline"> 
                <?php echo csrf_field(); ?>   
                <div class="textSearch">Search Pizza</div>
                <?php if($searchKey==""): ?>
                    <input class="imputData" type="text" name="pizzaName" placeHolder="Search Some Pizza">  
                <?php else: ?>
                    <input class="imputData" type="text" name="pizzaName" value="<?php echo e($searchKey); ?>">  
                <?php endif; ?>
                <input type="submit" value="Search" class="submitButon"> 
            </form>  
        <?php endif; ?>    

        <div class="displayPizza"> 
            <?php if($listPizzas->isEmpty()): ?>
                <div class="notFound">
                    Sorry there is no pizza
                </div>
            <?php endif; ?>
            <?php $__currentLoopData = $listPizzas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listPizza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="pizzaWrapper">  
                    <a href="<?php echo e(url('pizzaDetail/'.$listPizza->id)); ?>">                       
                        <img class="pizzaImage" src="<?php echo e(asset('storage/'.$listPizza->image)); ?>" >
                        <div class="pizzaTitle">                       
                            <?php echo e($listPizza->name); ?>

                        </div> 
                        <div class="pizzaPrice">
                            Rp. <?php echo e($listPizza->price); ?>

                        </div>  
                        <?php if(Illuminate\Support\Facades\Auth::check() && Illuminate\Support\Facades\Auth::User()->role == "admin"): ?> 
                            <div class="pizzaButtonWrapper">
                                 
                                <a href="<?php echo e(url('updatePizza/'.$listPizza->id)); ?>">
                                    <div class="pizzaButton">
                                        Update Pizza
                                    </div> 
                                </a> 
                                <a href="<?php echo e(url('deletePizza/'.$listPizza->id)); ?>">
                                    <div class="pizzaButton">
                                        Delete Pizza
                                    </div> 
                                </a> 
                            </div>
                        <?php endif; ?>
                    </a>  
                </div> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="pagination">
            <?php echo e($listPizzas->links()); ?>   
        </div>
    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS\Semester 5\Web Lab\project lab\project\resources\views/home.blade.php ENDPATH**/ ?>