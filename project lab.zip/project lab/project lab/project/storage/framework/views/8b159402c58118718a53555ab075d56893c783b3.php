<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/headerFooter.css')); ?>"> 
    <?php echo $__env->yieldContent('cssPage'); ?>
    <title>Phizaa Hut</title>
</head>
<body>
    <div class="header"> 
        <a href="<?php echo e(url('/')); ?>"  class="headerLogoWrapper">
            <img src="<?php echo e(asset('storage/img/logo.png')); ?>" class="headerLogo"> 
            <div class="headerLogoText">
                PHizza Hut
            </div> 
        </a>
        <div class="headerButtonWrapper"> 
            <?php if(!Illuminate\Support\Facades\Auth::check()): ?>
                <a href="<?php echo e(url('register')); ?>" class="headerButtom">
                    Register 
                </a>
                <a href="<?php echo e(url('login')); ?>" class="headerButtom"> 
                    Login 
                </a>
            <?php elseif(Illuminate\Support\Facades\Auth::User()->role == "member"): ?>
                <div class="headerDropdownWrapper">
                    <div class="headerDropdownUsername">
                        <?php echo e(Illuminate\Support\Facades\Auth::User()->username); ?>

                        <img src="<?php echo e(asset('storage/img/dropdown.png')); ?>" height="12px" width="auto">
                    </div>
                    <div class="headerDropdownList">
                        <a href="<?php echo e(url('logout')); ?>" class="headerDropdownListItem">Logout</a>
                    </div>
                </div>           
                <a href="<?php echo e(url('viewCart')); ?>" class="headerButtom">     
                    View Cart 
                </a>
                <a href="<?php echo e(url('viewTransactionHistory')); ?>" class="headerButtom"> 
                    View Transaction History 
                </a> 
            <?php elseif(Illuminate\Support\Facades\Auth::User()->role == "admin"): ?>
                <div class="headerDropdownWrapper">
                    <div class="headerDropdownUsername">
                        <?php echo e(Illuminate\Support\Facades\Auth::User()->username); ?>

                        <img src="<?php echo e(asset('storage/img/dropdown.png')); ?>" height="12px" width="auto">
                    </div>
                    <div class="headerDropdownList">
                        <a href="<?php echo e(url('logout')); ?>" class="headerDropdownListItem">Logout</a>
                    </div>
                </div>
                <a href="<?php echo e(url('viewAllUser')); ?>" class="headerButtom"> 
                        View All User 
                </a>
                <a href="<?php echo e(url('viewAllUserTransaction')); ?>" class="headerButtom"> 
                    View All User Transaction 
                </a>   
            <?php endif; ?>
        </div> 
    </div>
    <?php echo $__env->yieldContent('contentWrapper'); ?>  
</body>
</html><?php /**PATH D:\TUGAS\Semester 5\Web Lab\project lab\project\resources\views/template.blade.php ENDPATH**/ ?>