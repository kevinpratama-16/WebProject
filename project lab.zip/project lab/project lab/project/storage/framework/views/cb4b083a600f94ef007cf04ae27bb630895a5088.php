<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/headerFooter.css">
    <title>Template</title>
</head>
<body>
    <div class="header"> 
        <img src="image/logo.png" class="headerLogo"> 
        <div class="headerLogoText">
            PHizza Hut
        </div> 
        
        <div class="headerButtonWrapper">
            <?php if(Illuminate\Support\Facades\Session::get('role') == "member"): ?>
                <div class="username">
                    Username
                </div>
                <div class="headerButtom">
                    <a href="">View Cart</a>
                </div>
                <div class="headerButtom">
                    <a href="">View Transaction History</a>
                </div>
            <?php elseif(Illuminate\Support\Facades\Session::get('role') == "admin"): ?>
                <div class="username">
                    Username
                </div>
                <div class="headerButtom">
                    <a href="">View All User</a>
                </div>
                <div class="headerButtom">
                    <a href="">View All User Transaction</a>
                </div>
            <?php else: ?>
                <div class="headerButtom">
                    <a href="">Register</a>
                </div>
                <div class="headerButtom">
                    <a href="">Login</a>
                </div>
            <?php endif; ?>
        </div> 
    </div>
    <div class="content">

    </div>
    <div class="footer">

    </div>
</body>
</html><?php /**PATH D:\TUGAS\Semester 5\Web Lab\project\project\resources\views/template.blade.php ENDPATH**/ ?>