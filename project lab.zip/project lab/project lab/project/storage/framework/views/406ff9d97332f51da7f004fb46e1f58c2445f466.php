<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/headerFooter.css')); ?>"> 
    <link rel="stylesheet" href="<?php echo e(asset('css/pizzaDetail.css')); ?>">
    <title><?php echo e($pizza->name); ?></title>
</head>
<body>
    <div class="header"> 
        <a href="<?php echo e(url('/')); ?>"  class="headerLogoWrapper">
            <img src="<?php echo e(asset('storage/img/logo.png')); ?>" class="headerLogo"> 
            <div class="headerLogoText">
                PHizza Hut
            </div> 
        </a>
        <div class="headerButtonWrapper"> 
            <?php if($currentRole == "member"): ?>
                <div class="headerDropdownWrapper">
                    <div class="headerDropdownUsername">
                        <?php echo e($currentUsername); ?>

                        <img src="<?php echo e(asset('storage/img/dropdown.png')); ?>" height="12px" width="auto">
                    </div>
                    <div class="headerDropdownList">
                        <a href="<?php echo e(url('logout')); ?>" class="headerDropdownListItem">Logout</a>
                    </div>
                </div>                    
                <div class="headerButtom">
                    <a href="">View Cart</a>
                </div>
                <div class="headerButtom">
                    <a href="">View Transaction History</a>
                </div>
            <?php elseif($currentRole == "admin"): ?>
                <div class="headerDropdownWrapper">
                    <div class="headerDropdownUsername">
                        <?php echo e($currentUsername); ?>

                        <img src="<?php echo e(asset('storage/img/dropdown.png')); ?>" height="12px" width="auto">
                    </div>
                    <div class="headerDropdownList">
                        <a href="<?php echo e(url('logout')); ?>" class="headerDropdownListItem">Logout</a>
                    </div>
                </div>
                <div class="headerButtom">
                    <a href="viewAllUser">View All User</a>
                </div>
                <div class="headerButtom">
                    <a href="">View All User Transaction</a>
                </div>
            <?php else: ?>
                <div class="headerButtom">
                    <a href="<?php echo e(url('register')); ?>">Register</a>
                </div>
                <div class="headerButtom">
                    <a href="<?php echo e(url('login')); ?>">Login</a>
                </div>
            <?php endif; ?>
        </div> 
    </div>
    <div class="content">  
        <img class="pizzaImage" src="<?php echo e(asset('storage/'.$pizza->image)); ?>"> 
        <div class="pizzaDetail">         
            <div class="pizzaTitle">
                <?php echo e($pizza->name); ?> 
            </div>
            <div class="pizzaDescription">
                <?php echo e($pizza->description); ?>

            </div>
            <div class="pizzaPrice">
                Rp. <?php echo e($pizza->price); ?>

            </div>
            <?php if($currentRole == "member"): ?>
                <form action="<?php echo e(url('/addToChart')); ?>" method="POST" style="display: flex;"> 
                    <?php echo csrf_field(); ?> 
                    <div class="textQuantity">Quantity </div>
                    <input class="imputData" type="text" name="pizzaQuantity">  
                    <input type="submit" value="Add to Cart" class="submitButon"> 
                </form> 
            <?php endif; ?>
        </div>
    </div> 
</body>
</html><?php /**PATH D:\TUGAS\Semester 5\Web Lab\project\project\resources\views/pizzaDetail.blade.php ENDPATH**/ ?>