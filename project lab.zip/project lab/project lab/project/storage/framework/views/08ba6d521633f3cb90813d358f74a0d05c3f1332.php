<?php $__env->startSection('cssPage'); ?>
    <link rel="stylesheet" href="css/register.css">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('contentWrapper'); ?>
    <div class="content">
        <div class="registerTitle">
            Register
        </div>
        <?php if($errors->first()!=""): ?>
            <div class="errorMessage">
                <?php echo e($errors->first()); ?>

            </div>       
        <?php endif; ?>  
        <form action="<?php echo e(url('/register')); ?>" method="POST" class="registerDetail"> 
            <?php echo csrf_field(); ?> 
            <input class="imputData" type="text" name="username" placeholder="Username">  
            <input class="imputData" type="text" name="email" placeholder="E-mail Address">  
            <input class="imputData" type="password" name="password" placeholder="Password">  
            <input class="imputData" type="password" name="confirmPassword" placeholder="Confirm Password">  
            <input class="imputData" type="text" name="address" placeholder="Address">  
            <input class="imputData" type="text" name="phoneNumber" placeholder="phoneNumber">  
            Gender
            <input class="imputRadio" type="radio" name="gender" value="male"> Male
            <input class="imputRadio" type="radio" value="female" name="gender"> Female<br>
            <div class="registerButom">
                <input type="submit" value="Register" class="submitButon"> 
            </div>
        </form>   
    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS\Semester 5\Web Lab\project lab\project\resources\views/register.blade.php ENDPATH**/ ?>