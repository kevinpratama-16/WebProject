<?php $__env->startSection('cssPage'); ?>
    <link rel="stylesheet" href="css/login.css">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('contentWrapper'); ?>
    <div class="content">
        <div class="loginTitle">
            Forgot Password
        </div>
        <?php if(!$errors->isEmpty()): ?>
            <div class="errorMessage">
                <?php echo e($errors->first()); ?>

            </div>       
        <?php endif; ?>  
        <form action="<?php echo e(url('forgotPassword')); ?>" method="post" class="loginDetail"> 
            <?php echo csrf_field(); ?> 
            <input class="imputData" type="text" name="email" placeholder="E-mail Address">   
            <div class="loginButom">
                <input type="submit" value="Check Email" class="submitButon"> 
            </div>
        </form>   
    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS\Semester 5\Web Lab\project lab\project\resources\views/forgotPassword.blade.php ENDPATH**/ ?>