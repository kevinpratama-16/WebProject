<?php $__env->startSection('cssPage'); ?> 
    <link rel="stylesheet" href=<?php echo e(asset('css/viewCart.css')); ?>>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('contentWrapper'); ?> 
    <div class="content"> 
        <div class="titlePage">
            Cart
        </div>
        <?php if(!$errors->isEmpty()): ?>
            <div class="errorMessage">
                <?php echo e($errors->first()); ?>

            </div>       
        <?php endif; ?>   
        <?php if($listCarts->isEmpty()): ?>
            <div class="noData">
                There is No data
            </div>
        <?php else: ?>
            <a href="<?php echo e(url('insertTransaction')); ?>">  
                <div class="checkOutButtom">
                    Check Out
                </div>   
            </a>
        <?php endif; ?>
        <?php $__currentLoopData = $listCarts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listCart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="cartWrapper">
                <div class="image">
                    <img src="<?php echo e(asset('storage/'.$listCart->pizza->first()->image)); ?>" height="100%" width="400">
                </div>
                <div class="desciption"> 
                    <a href="<?php echo e(url('removeCart/'.$listCart->pizza->first()->id)); ?>" class="deleteButton"> 
                        <img src="<?php echo e(asset('storage/img/trash.png')); ?>" height="30px" width="30px">
                    </a>
                    <div class="title">
                        <?php echo e($listCart->pizza->first()->name); ?>

                    </div>
                    <div class="detail">
                        <div>Price </div>
                        <div>Rp. <?php echo e($listCart->pizza->first()->price); ?></div>
                        <div>Quantity</div>
                        <div><?php echo e($listCart->quantity); ?></div>  
                    </div> 
                    <form action="<?php echo e(url('updateQuantity/'.$currentUserId.'/'.$listCart->pizza->first()->id)); ?>" method="POST" style="display: flex;"> 
                        <?php echo csrf_field(); ?> 
                        <div class="textQuantity">Quantity </div>
                        <input class="imputData" type="text" name="pizzaQuantity">  
                        <input type="submit" value="Update Quantity" class="submitButon"> 
                    </form> 
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS\Semester 5\Web Lab\project lab\project\resources\views/viewCart.blade.php ENDPATH**/ ?>