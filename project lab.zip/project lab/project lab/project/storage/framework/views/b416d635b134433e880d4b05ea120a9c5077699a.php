<?php $__env->startSection('cssPage'); ?>
    <link rel="stylesheet" href="css/login.css">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('contentWrapper'); ?>
    <div class="content">
        <div class="loginTitle">
            Login
        </div>
        <?php if(!$errors->isEmpty()): ?>
            <div class="errorMessage">
                <?php echo e($errors->first()); ?>

            </div>       
        <?php endif; ?>  
        <form action="<?php echo e(url('/login')); ?>" method="POSt" class="loginDetail"> 
            <?php echo csrf_field(); ?> 
            <input class="imputData" type="text" name="email" placeholder="E-mail Address">  
            <input class="imputData" type="password" name="password" placeholder="Password">  
            <div class="checkBox">
                <input type="checkbox" name="rememberMe"> Remember Me 
            </div>
            <div class="loginButom">
                <input type="submit" value="Login" class="submitButon">
                <a href="<?php echo e(url('/forgotPassword')); ?>">Forgot Password</a>
            </div>
        </form>   
    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS\Semester 5\Web Lab\project lab\project\resources\views/login.blade.php ENDPATH**/ ?>