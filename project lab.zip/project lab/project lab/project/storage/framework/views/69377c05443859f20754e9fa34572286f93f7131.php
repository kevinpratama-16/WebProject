<?php $__env->startSection('cssPage'); ?>
    <link rel="stylesheet" href="css/viewAllUser.css">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('contentWrapper'); ?> 
    <div class="content">  
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <div class="userWrapper">
                <div class="userId">
                    User ID : <?php echo e($user->id); ?>

                </div>
                <div class="firstUserData">
                    Username : <?php echo e($user->username); ?>

                </div>
                <div class="userData">
                    Email : <?php echo e($user->email); ?>

                </div>
                <div class="userData">
                    Address : <?php echo e($user->address); ?>

                </div>
                <div class="userData">
                    Phone : <?php echo e($user->phoneNumber); ?>

                </div>
                <div class="userData">
                    Gender : <?php echo e($user->gender); ?>

                </div>
            </div>  
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS\Semester 5\Web Lab\project lab\project\resources\views/viewAllUser.blade.php ENDPATH**/ ?>