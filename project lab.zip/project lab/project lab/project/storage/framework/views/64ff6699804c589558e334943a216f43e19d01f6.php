<?php $__env->startSection('cssPage'); ?>
    <link rel="stylesheet" href=<?php echo e(asset('css/pizzaDetail.css')); ?>>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('contentWrapper'); ?> 
    <div class="content">  
        <img class="pizzaImage" src="<?php echo e(asset('storage/'.$pizza->image)); ?>"> 
        <div class="pizzaDetail">         
            <div class="pizzaTitle">
                <?php echo e($pizza->name); ?> 
            </div>
            <div class="pizzaDescription">
                <?php echo e($pizza->description); ?>

            </div>
            <div class="pizzaPrice">
                Rp. <?php echo e($pizza->price); ?>

            </div>
            <?php if(Illuminate\Support\Facades\Auth::check() && Illuminate\Support\Facades\Auth::User()->role == "member"): ?> 
                <?php if(!$errors->isEmpty()): ?>
                    <div class="errorMessage">
                        <?php echo e($errors->first()); ?>

                    </div>       
                <?php endif; ?>      
                <form action="<?php echo e(url('addToCart/'.$pizza->id)); ?>" method="POST" style="display: flex;"> 
                    <?php echo csrf_field(); ?> 
                    <div class="textQuantity">Quantity </div>
                    <input class="imputData" type="text" name="pizzaQuantity">  
                    <input type="submit" value="Add to Cart" class="submitButon"> 
                </form> 
            <?php endif; ?>
        </div>
    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS\Semester 5\Web Lab\project lab\project\resources\views/pizzaDetail.blade.php ENDPATH**/ ?>