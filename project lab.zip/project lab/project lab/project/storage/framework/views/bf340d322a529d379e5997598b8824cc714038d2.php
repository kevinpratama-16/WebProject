<?php $__env->startSection('cssPage'); ?> 
    <link rel="stylesheet" href=<?php echo e(asset('css/viewTransactionHistory.css')); ?>>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('contentWrapper'); ?> 
    <div class="content"> 
        <div class="titlePage">
            View Transaction History
        </div> 
 
        <?php if($listTransactions->isEmpty()): ?>
            <div class="noData">
                There is No data
            </div> 
        <?php endif; ?> 
 
        <?php $__currentLoopData = $listTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listTransaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <a href="<?php echo e(url('viewDetailTransaction/'.$listTransaction->id)); ?>"> 
                <div class="transaction"> 
                    Transaction at <?php echo e($listTransaction->created_at); ?>

                </div>                
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS\Semester 5\Web Lab\project lab\project\resources\views/viewTransactionHistory.blade.php ENDPATH**/ ?>