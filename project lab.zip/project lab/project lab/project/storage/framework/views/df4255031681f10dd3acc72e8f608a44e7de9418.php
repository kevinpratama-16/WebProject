<?php $__env->startSection('cssPage'); ?>
    <link rel="stylesheet" href="css/viewAllUser.css">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('contentWrapper'); ?> 
    <div class="content">  
        <?php $__currentLoopData = $listTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listTransaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <a href="<?php echo e(url('viewDetailTransaction/'.$listTransaction->id)); ?>"> 
                <div class="userWrapper">
                    <div class="transactionDate">
                        Transaction at <?php echo e($listTransaction->created_at); ?>

                    </div>
                    <div class="firstUserData">
                        Username : <?php echo e($listTransaction->users->first()->username); ?>

                    </div>
                    <div class="userData">
                        User ID : <?php echo e($listTransaction->user_id); ?>

                    </div> 
                </div>  
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS\Semester 5\Web Lab\project lab\project\resources\views/viewAllUserTransaction.blade.php ENDPATH**/ ?>