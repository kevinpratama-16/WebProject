<?php $__env->startSection('cssPage'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/updatePizza.css')); ?>">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('contentWrapper'); ?> 
    <div class="content">
        <img class="pizzaImage" src="<?php echo e(asset('storage/'.$pizza->image)); ?>" >
        <div class="addNewPizzaTitle">
            Update Pizza
        </div>
        <?php if($errors->first()!=""): ?>
            <div class="errorMessage">
                <?php echo e($errors->first()); ?>

            </div>       
        <?php endif; ?>  
        <form action="<?php echo e(url('updatePizza/'.$pizza->id)); ?>" method="POST" class="formDetail" enctype="multipart/form-data"> 
            <?php echo csrf_field(); ?> 
            <span>Pizza Name</span>
            <input class="imputData" type="text" name="pizzaName" placeholder="Pizza Name">  
            <span>Pizza Price</span>
            <input class="imputData" type="text" name="pizzaPrice" placeholder="Pizza Price">  
            <span>Pizza Description</span>
            <input class="imputData" type="text" name="pizzaDescription" placeholder="Pizza Description">  
            <span>Pizza Image</span>
            <div>
                <input class="imputFile" type="file" name="pizzaImage">   
                <input type="submit" value="Update Pizza" class="submitButon">  
            </div>
        </form>   
    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TUGAS\Semester 5\Web Lab\project lab\project\resources\views/updatePizza.blade.php ENDPATH**/ ?>