<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/headerFooter.css">
    <link rel="stylesheet" href="css/addNewPizza.css">
    <title>Add New Pizza</title>
</head>
<body>
    <div class="header"> 
        <a href="<?php echo e(url('/')); ?>"  class="headerLogoWrapper">
            <img src="<?php echo e(asset('storage/img//logo.png')); ?>" class="headerLogo"> 
            <div class="headerLogoText">
                PHizza Hut
            </div> 
        </a>
        
        <div class="headerButtonWrapper"> 
            <div class="headerDropdownWrapper">
                <div class="headerDropdownUsername">
                    <?php echo e($currentUsername); ?>

                    <img src="<?php echo e(asset('storage/img/dropdown.png')); ?>" height="12px" width="auto">
                </div>
                <div class="headerDropdownList">
                    <a href="<?php echo e(url('logout')); ?>" class="headerDropdownListItem">Logout</a>
                </div>
            </div>
            <div class="headerButtom">
                <a href="viewAllUser">View All User</a>
            </div>
            <div class="headerButtom">
                <a href="">View All User Transaction</a>
            </div> 
        </div> 
    </div>
    <div class="content">
        <div class="addNewPizzaTitle">
            Add New Pizza
        </div>
        <?php if($errors->first()!=""): ?>
            <div class="errorMessage">
                <?php echo e($errors->first()); ?>

            </div>       
        <?php endif; ?>  
        <form action="<?php echo e(url('/addNewPizza')); ?>" method="POST" class="formDetail" enctype="multipart/form-data"> 
            <?php echo csrf_field(); ?> 
            <span>Pizza Name</span>
            <input class="imputData" type="text" name="pizzaName" placeholder="Pizza Name">  
            <span>Pizza Price</span>
            <input class="imputData" type="text" name="pizzaPrice" placeholder="Pizza Price">  
            <span>Pizza Description</span>
            <input class="imputData" type="text" name="pizzaDescription" placeholder="Pizza Description">  
            <span>Pizza Image</span>
            <input class="imputFile" type="file" name="pizzaImage">   
            <input type="submit" value="Add Pizza" class="submitButon">  
        </form>   
    </div> 
</body>
</html><?php /**PATH D:\TUGAS\Semester 5\Web Lab\project\project\resources\views/addNewPizza.blade.php ENDPATH**/ ?>