<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/headerFooter.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
    <title>Forgot Password</title>
</head>
<body>
    <div class="header"> 
        <a href="<?php echo e(url('/')); ?>"  class="headerLogoWrapper">
            <img src="<?php echo e(asset('storage/img/logo.png')); ?>" class="headerLogo"> 
            <div class="headerLogoText">
                PHizza Hut
            </div> 
        </a>
        
        <div class="headerButtonWrapper"> 
           <a href="<?php echo e(url('register')); ?>" class="headerButtom">
                Register 
            </a>
            <a href="<?php echo e(url('login')); ?>" class="headerButtom"> 
                Login 
            </a>
        </div> 
    </div>
    <div class="content">
        <div class="loginTitle">
            Forgot Password
        </div>
        <?php if(!$errors->isEmpty()): ?>
            <div class="errorMessage">
                <?php echo e($errors->first()); ?>

            </div>       
        <?php endif; ?>  
        <form action="<?php echo e(url('/forgotPasswordForm')); ?>" method="POSt" class="loginDetail"> 
            <?php echo csrf_field(); ?> 
            <input class="imputData" type="text" name="email" value=<?php echo e($userEmail); ?>>  
            <input class="imputDataForgot" type="password" name="password" placeholder="Password">  
            <input class="imputDataForgot" type="password" name="confirmPassword" placeholder="Password">
             
            <div class="loginButom">
                <input type="submit" value="Change Password" class="submitButon">
            </div>
        </form>   
    </div> 
</body>
</html><?php /**PATH D:\TUGAS\Semester 5\Web Lab\project lab\project\resources\views/forgotPasswordForm.blade.php ENDPATH**/ ?>